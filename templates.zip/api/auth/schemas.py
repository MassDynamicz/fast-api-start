#auth/schemas.py

from pydantic import BaseModel, EmailStr
from typing import List, Optional
from datetime import datetime

class RoleBase(BaseModel):
    name: str
    description: Optional[str] = None

class RoleCreate(RoleBase):
    pass

class Role(RoleBase):
    id: int

    class Config:
        from_attributes = True

class UserSessionBase(BaseModel):
    session_start: datetime
    session_end: Optional[datetime] = None
    data_used: int
    description: Optional[str] = None

class UserSessionCreate(UserSessionBase):
    pass

class UserSession(UserSessionBase):
    id: int
    user_id: int

    class Config:
        from_attributes = True

class UserBase(BaseModel):
    username: str
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    email: EmailStr
    phone: Optional[str] = None
    address: Optional[str] = None
    company: Optional[str] = None
    is_active: bool = True
    is_admin: bool = False
    last_login_at: Optional[datetime] = None

class UserCreate(UserBase):
    hashed_password: str

class User(UserBase):
    id: int
    roles: List[Role] = []
    sessions: List[UserSession] = []

    class Config:
        from_attributes = True
