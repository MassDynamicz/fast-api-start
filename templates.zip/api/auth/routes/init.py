from fastapi import APIRouter
from .users import router as users_router
from .sessions import router as sessions_router
from .roles import router as roles_router

router = APIRouter()

router.include_router(users_router, prefix="/users", tags=["users"])
router.include_router(sessions_router, prefix="/sessions", tags=["sessions"])
router.include_router(roles_router, prefix="/roles", tags=["roles"])
