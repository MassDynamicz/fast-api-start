#auth/routes/users.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from config.db import get_db
from .. import models, schemas
from ..schemas import UserCreate
from config.utils import get_password_hash
from typing import List

router = APIRouter()

#Создание пользователя
@router.post("/users/",tags=["Пользователи"],response_model=schemas.User)
def create_user(user: UserCreate, db: Session = Depends(get_db)):
    db_user = db.query(models.User).filter(models.User.email == user.email).first()
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    hashed_password = get_password_hash(user.hashed_password)
    db_user = models.User(**user.dict(exclude={"hashed_password"}), hashed_password=hashed_password)
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

#Получение списка пользователей
@router.get("/users/",tags=["Пользователи"], response_model=List[schemas.User])
def read_users(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    users = db.query(models.User).offset(skip).limit(limit).all()
    return users

#Пользователь
@router.get("/users/{user_id}",tags=["Пользователи"],response_model=schemas.User)
def read_user(user_id: int, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    return user

#Обноление пользователя
@router.put("/users/{user_id}",tags=["Пользователи"], response_model=schemas.User)
def update_user(user_id: int, user: UserCreate, db: Session = Depends(get_db)):
    db_user = db.query(models.User).filter(models.User.id == user_id).first()
    if db_user is None:
        raise HTTPException(status_code=404, detail="User not found")
    for key, value in user.dict(exclude_unset=True).items():
        if key == "hashed_password":
            value = get_password_hash(value)
        setattr(db_user, key, value)
    db.commit()
    db.refresh(db_user)
    return db_user

#Удаление пользователя
@router.delete("/users/{user_id}",tags=["Пользователи"], response_model=schemas.User)
def delete_user(user_id: int, db: Session = Depends(get_db)):
    db_user = db.query(models.User).filter(models.User.id == user_id).first()
    if db_user is None:
        raise HTTPException(status_code=404, detail="User not found")
    db.delete(db_user)
    db.commit()
    return db_user
