# api/__init__.py
import pkgutil
import importlib

def import_submodules(package_name):
    """Импортирует все подмодули в заданном пакете."""
    package = importlib.import_module(package_name)
    for loader, module_name, is_pkg in pkgutil.walk_packages(package.__path__, package.__name__ + "."):
        importlib.import_module(module_name)

import_submodules(__name__)
