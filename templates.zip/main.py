# main.py
from fastapi import Request
from api.auth.routes.users import router as auth_router
from config.settings import app, templates

app.include_router(auth_router, prefix="/api")

# Пример корневого маршрута
@app.get("/")
async def read_root(request: Request):
    data = {"request": request, "title": 'Главная Expeditor'}
    return templates.TemplateResponse("index.html", data)

@app.get("/login/")
async def login_page(request: Request):
    data = {"request": request, "title": 'Страница авторизации'}
    return templates.TemplateResponse("users/login.html", data)

