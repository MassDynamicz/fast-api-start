# config/settings.py
from fastapi import FastAPI, Request, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from config.middleware import add_cors_middleware

# Папка с шаблонами
templates = Jinja2Templates(directory="templates")

def create_app() -> FastAPI:
    app = FastAPI(title="Expeditor")

    # Добавление CORS middleware
    add_cors_middleware(app)

    # Подключение статических файлов
    app.mount("/static", StaticFiles(directory="static"), name="static")
    app.mount("/templates", StaticFiles(directory="templates"), name="templates")
    app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")
    
    # Обработчик для ошибки 404
    @app.exception_handler(404)
    async def not_found_exception_handler(request: Request, exc: HTTPException):
        return templates.TemplateResponse(
            "layouts/errors.html", 
            {"request": request, "status_code": 404, "message": "Страница не найдена"},
            status_code=404
        )
    
    return app

app = create_app()

